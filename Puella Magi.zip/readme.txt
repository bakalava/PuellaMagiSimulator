Puella Magi Madoka Magica Sim Readme
==============================================

Extract all of the files in the zip folder into 1 folder.

To run the program, open PuellaMagi.jar.

To read the user guide, open PuellaMagiUserGuide.ppt.pdf.

To read the program documentation, open index.html in the doc folder.

==============================================

Program by:

Tony Cui
Jiayin Huang
Sally Hui